TAKE MUSIC — CLOUDFLARE WORKERS STATIC ASSETS
================================================
ไฟล์ในแพ็กเกจ:
- public/index.html : หน้าเว็บ
- src/index.js : Worker ส่งไฟล์เว็บ
- wrangler.jsonc : ตั้งค่า Cloudflare Workers Static Assets

วิธีเชื่อมกับ GitHub repository ที่ Cloudflare project `take` ใช้อยู่:
1. แตก ZIP แล้วอัปโหลดไฟล์/โฟลเดอร์ทั้งหมดเข้า root ของ repository เดิม (แทนไฟล์เดิมที่ชื่อซ้ำ)
2. Commit และ push
3. ใน Cloudflare Workers & Pages > take > Settings > Builds ให้ตั้ง:
   Build command: เว้นว่าง / None
   Deploy command: npx wrangler deploy
   Root directory: /
4. กลับหน้า Deployments แล้วรอ Deploy จบเป็น Success

Supabase ที่ตั้งไว้:
- project URL และ publishable key ใน public/index.html
- database table: public.tracks
- storage bucket: TAKE-MUSIC

สำคัญ:
- ต้องมี tracks columns: user_id, title, artist_name, audio_path, status, created_at
- ต้องมี SELECT policy สำหรับเพลง status='approved'
- ต้องมี INSERT policy ที่ยอมให้ authenticated เพิ่มแถวของตนเอง status='approved'
- Storage bucket TAKE-MUSIC ต้องมี INSERT policy สำหรับ authenticated user ในโฟลเดอร์ user UUID
- Bucket ต้องเป็น Public เพื่อใช้ getPublicUrl เล่นเพลง
- อย่าใส่ service_role/secret key ในหน้าเว็บ
- หาก policy ไม่ตรง ระบบจะขึ้นข้อความ error ในหน้าเว็บ

ไฟล์นี้ยังไม่ได้ถูก push เข้า GitHub หรือ Deploy ให้คุณ และยังไม่ได้ทดสอบกับ Supabase จริงจากบัญชีของคุณ.
